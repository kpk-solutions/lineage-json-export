from collections import defaultdict, deque
import pandas as pd

def calculate_lineage(group_level, jobname, relatedpredjobs, root):
    df = pd.DataFrame({
        'group_level': group_level,
        'jobname': jobname,
        'relatedpredjobs': [j.split(',') for j in relatedpredjobs]
    })

    asc_graph = defaultdict(list)
    desc_graph = defaultdict(list)

    for _, row in df.iterrows():
        job = row['jobname']
        for related in row['relatedpredjobs']:
            related = related.strip()
            if row['group_level'] < 0:
                asc_graph[job].append(related)
                desc_graph[related].append(job)
            else:
                desc_graph[job].append(related)
                asc_graph[related].append(job)

    visited = {}
    visited[root] = {'id': root, 'level': 0, 'ascendants': [], 'descendants': []}

    asc_queue = deque([(root, 0)])
    while asc_queue:
        current, level = asc_queue.popleft()
        for parent in asc_graph.get(current, []):
            if parent not in visited:
                visited[parent] = {'id': parent, 'level': level - 1, 'ascendants': [], 'descendants': []}
                asc_queue.append((parent, level - 1))
            if parent not in visited[current]['ascendants']:
                visited[current]['ascendants'].append(parent)
            if current not in visited[parent]['descendants']:
                visited[parent]['descendants'].append(current)

    desc_queue = deque([(root, 0)])
    while desc_queue:
        current, level = desc_queue.popleft()
        for child in desc_graph.get(current, []):
            if child not in visited:
                visited[child] = {'id': child, 'level': level + 1, 'ascendants': [], 'descendants': []}
                desc_queue.append((child, level + 1))
            if child not in visited[current]['descendants']:
                visited[current]['descendants'].append(child)
            if current not in visited[child]['ascendants']:
                visited[child]['ascendants'].append(current)

    return {
        'root': root,
        'nodes': sorted(visited.values(), key=lambda x: x['level'])
    }
