from fastapi import APIRouter, Body
from typing import List
from app.services.lineage_service import calculate_lineage

router = APIRouter()

@router.post("/")
def get_lineage(
    group_level: List[int] = Body(...),
    jobname: List[str] = Body(...),
    relatedpredjobs: List[str] = Body(...),
    root: str = Body(...)
):
    return calculate_lineage(group_level, jobname, relatedpredjobs, root)
