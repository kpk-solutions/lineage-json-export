from fastapi import FastAPI
from app.api.endpoints import lineage

app = FastAPI(title="Lineage API")

app.include_router(lineage.router, prefix="/api/lineage")
