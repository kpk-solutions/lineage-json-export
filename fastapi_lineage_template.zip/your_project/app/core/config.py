class Settings:
    PROJECT_NAME: str = "Lineage API"
    API_V1_STR: str = "/api"

settings = Settings()
