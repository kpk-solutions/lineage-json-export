from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

app = FastAPI()

# Serve frontend static files
app.mount("/static", StaticFiles(directory="frontend"), name="static")

# Serve index.html for root and unmatched routes
@app.get("/{full_path:path}")
async def serve_spa(full_path: str):
    return FileResponse(os.path.join("frontend", "index.html"))

# Sample API endpoint
@app.get("/api/hello")
async def hello():
    return {"message": "Hello from FastAPI backend!"}