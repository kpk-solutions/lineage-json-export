from fastapi import Request
from fastapi.responses import JSONResponse

async def sso_auth_middleware(request: Request, call_next):
    if "Authorization" not in request.headers:
        return JSONResponse(status_code=401, content={"error": "Unauthorized"})
    return await call_next(request)
