from fastapi import FastAPI
from app.api import router as api_router
from app.core.auth import sso_auth_middleware

app = FastAPI()

app.middleware("http")(sso_auth_middleware)

app.include_router(api_router)
