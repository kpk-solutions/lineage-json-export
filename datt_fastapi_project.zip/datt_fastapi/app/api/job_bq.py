from fastapi import APIRouter
from app.schema.job import JobSchema
from app.service.bq_service import insert_job_bq, fetch_jobs_bq, delete_job_bq

router = APIRouter()

@router.post("/insert")
def insert_bq(job: JobSchema):
    return insert_job_bq(job)

@router.get("/fetch")
def fetch_bq():
    return fetch_jobs_bq()

@router.delete("/delete/{job_id}")
def delete_bq(job_id: str):
    return delete_job_bq(job_id)
