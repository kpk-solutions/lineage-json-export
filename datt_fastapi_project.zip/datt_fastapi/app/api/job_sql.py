from fastapi import APIRouter, HTTPException
from app.schema.job import JobSchema
from app.service.sql_service import insert_job, delete_job, fetch_jobs

router = APIRouter()

@router.post("/insert")
def insert(job: JobSchema):
    return insert_job(job)

@router.get("/fetch")
def fetch():
    return fetch_jobs()

@router.delete("/delete/{job_id}")
def delete(job_id: int):
    return delete_job(job_id)
