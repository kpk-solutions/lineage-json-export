from fastapi import APIRouter
from app.api import job_sql, job_bq

router = APIRouter()
router.include_router(job_sql.router, prefix="/sql", tags=["SQL Server"])
router.include_router(job_bq.router, prefix="/bq", tags=["BigQuery"])
