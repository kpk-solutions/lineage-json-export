from pydantic import BaseModel

class JobSchema(BaseModel):
    job_id: int
    job_name: str
    status: str
