from google.cloud import bigquery
from app.schema.job import JobSchema
import os

client = bigquery.Client()

dataset = "your_dataset"
table = "your_table"

def insert_job_bq(job: JobSchema):
    table_id = f"{client.project}.{dataset}.{table}"
    errors = client.insert_rows_json(table_id, [job.dict()])
    if errors:
        return {"error": str(errors)}
    return {"message": "Inserted"}

def fetch_jobs_bq():
    query = f"SELECT * FROM `{client.project}.{dataset}.{table}`"
    results = client.query(query).result()
    return [dict(row) for row in results]

def delete_job_bq(job_id: str):
    query = f"DELETE FROM `{client.project}.{dataset}.{table}` WHERE job_id = '{job_id}'"
    client.query(query).result()
    return {"message": "Deleted"}
