from app.db.sql import get_sql_engine
from sqlalchemy import text
from app.schema.job import JobSchema

def insert_job(job: JobSchema):
    with get_sql_engine().connect() as conn:
        conn.execute(text("INSERT INTO jobs (job_id, job_name, status) VALUES (:job_id, :job_name, :status)"),
                     {"job_id": job.job_id, "job_name": job.job_name, "status": job.status})
        return {"message": "Inserted"}

def delete_job(job_id: int):
    with get_sql_engine().connect() as conn:
        conn.execute(text("DELETE FROM jobs WHERE job_id = :job_id"), {"job_id": job_id})
        return {"message": "Deleted"}

def fetch_jobs():
    with get_sql_engine().connect() as conn:
        result = conn.execute(text("SELECT * FROM jobs"))
        return [dict(row) for row in result]
