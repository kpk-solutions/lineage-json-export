from sqlalchemy import create_engine

def get_sql_engine():
    conn_str = "mssql+pyodbc://username:password@your_sql_server/db_name?driver=ODBC+Driver+17+for+SQL+Server"
    return create_engine(conn_str)
